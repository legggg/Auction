package com.example.j.controller;

import com.example.j.service.userService;
import com.example.j.vo.adminVO;
import com.example.j.vo.graduationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AdminController {
    @Autowired
    private userService userService;

    @GetMapping("/admin")
    public String getAdminList(Model model){
        List<adminVO> adminList = userService.getAdminList();
        model.addAttribute("adminList", adminList);




        return "1111";
    }
    @GetMapping("/g")
    public String getgList(Model model){
        List<graduationVO> graduationVOList = userService.getGraduationById("j");
        model.addAttribute("gList", graduationVOList);




        return "graduation";
    }
}
