package com.example.j.service;


import com.example.j.mapper.userMapper;
import com.example.j.vo.adminVO;
import com.example.j.vo.graduationVO;
import com.example.j.vo.historyVO;
import com.example.j.vo.userVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class userService {
    @Autowired
    private userMapper userMapper;

    public List<adminVO> getAdminList() {
        return userMapper.getAdminList();
    }
//    public String login(String userId, String userPw) {
//        userVO userVo = userMapper.getUserById(userId);
//        if (userVo.getUserPw().equals(userPw)) {
//            return userVo.getUserId();
//        }
//        return null;
//    }
    public userVO getUserById(String id) {
        return userMapper.getUserById(id);
    }

    public void signup(userVO userVo) {
        userMapper.insertUser(userVo);
    }

    public void modifyInfo(userVO userVo) {
        userMapper.updateUser(userVo);
    }
    //학력
    public List<graduationVO> getGraduationById(String id){
        return userMapper.getGraduationById(id);
    }

    public void insertGraduation(graduationVO gVo) {
        userMapper.insertGraduation(gVo);
    }

    public graduationVO getGraduationByIdNum(String userId,int num){
        return userMapper.getGraduationByIdNum(userId,num);
    }
    public void updateGrduation(graduationVO gVo) {userMapper.updateGrduation(gVo);}

    public void deleteGraduation(int num){userMapper.deleteGraduation(num);}
    //경력
    public List<historyVO> getHistoryById(String userId){
        return userMapper.getHistoryById(userId);
    }
    public historyVO getHistoryByIdNum(String userId,int hnum){
        return userMapper.getHistoryByIdNum(userId,hnum);
    }
    public void updateHistroy(historyVO hVo){
        userMapper.updateHistroy(hVo);
    }
    public void deleteHistory(int hnum){
        userMapper.deleteHistory(hnum);
    }

    public void insertHistory(historyVO hVo){
        userMapper.insertHistory(hVo);
    }
}
