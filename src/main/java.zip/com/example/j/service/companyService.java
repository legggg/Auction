package com.example.j.service;

import com.example.j.mapper.companyMapper;
import com.example.j.mapper.userMapper;
import com.example.j.vo.hrVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class companyService {
    @Autowired
    private companyMapper companyMapper;

    public hrVO getHrById(String hrId){return companyMapper.getHrById(hrId);}

    public void insertHr(hrVO hrVo){ companyMapper.insertHr(hrVo); }

    public void insertCompany(int comNum){companyMapper.insertCompany(comNum);}

}
