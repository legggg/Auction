package com.example.j.vo;

import lombok.Data;

@Data
public class adminVO {
    private String id;
    private String pw;
}
