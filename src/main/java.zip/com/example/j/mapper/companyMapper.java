package com.example.j.mapper;

import com.example.j.vo.hrVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface companyMapper {
    hrVO getHrById(String hrId);
    void insertHr(hrVO hrVo);
    void insertCompany(int comNum);
}
